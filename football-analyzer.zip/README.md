# football-analyzer

Bot Telegram para análise estatística de jogos de futebol.

## O que ele faz

- Recebe duas equipas pelo comando `/palpite`
- Consulta dados recentes
- Calcula probabilidades estimadas de casa/empate/fora
- Mostra os placares exatos mais prováveis
- Mostra as médias recentes de gols

## Exemplo

`/palpite Arsenal | Chelsea`

## Configuração

1. Crie um bot no Telegram com o BotFather e obtenha o `BOT_TOKEN`.
2. Obtenha uma chave da API-Football e coloque em `API_FOOTBALL_KEY`.
3. Instale as dependências:

```bash
pip install -r requirements.txt
```

4. Defina as variáveis de ambiente.
5. Execute:

```bash
python bot.py
```

As previsões são estimativas estatísticas e não garantem resultados.
